from scrapy import Request
from scrapy.spiders import CrawlSpider, Rule
from scrapy.selector import Selector
from scrapy.linkextractors import LinkExtractor

from ..items import AuktionItem

import time

from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.options import Options
from shutil import which

class AuktionSpider(CrawlSpider):

    name = "auktion"
    id = 0
    
    names = ["id","number_of_auction","date_of_auction","category_of_lot","images","lotnumber","description",
            "condition_of_item","catalog_number","estimate","sold_for"]
    
    star_urls=["https://auktionen.felzmann.de"]
    
    def __init__(self, new, *args, **kwargs):                    
        super(AuktionSpider, self).__init__(*args, **kwargs) 

        self.new = new

        if new == "no":
            id_file = open("id.txt","r")
            self.id = id_file.readline()
            self.id = self.id.strip("\n")

            self.id = int(self.id)
            id_file.close()

        file = open("input.txt","r")

        self.links = []

        for catg_id in file.readlines():
            catg_id = catg_id.replace("\n","")
            self.links.append(f"https://auktionen.felzmann.de/Auktion/KatalogArchiv?intAuktionsId={catg_id}")

        file.close()


    def start_requests(self):

        for links in self.links:
            yield Request(url=links,callback=self.page)

    
    def page(self,response):
        
        options = Options()
        options.add_argument("--headless")
        #chrome_options=options

        driver = webdriver.Chrome(chrome_options=options)
        
        driver.get(response.url)
    

        while True:     
            

            response = Selector(text=driver.page_source)
                    
            page = driver.find_elements_by_css_selector('.pager-forward a:first-child')
            
            
            for grid in response.css(".item"):
            
                product = AuktionItem()
                
                for name in self.names:
                    product[f"{name}"] = "None"
                
                product["number_of_auction"] = self.get_number_of_auktion(response) 
                product["date_of_auction"] = self.get_date_of_auction(response)     
                product["id"] = self.id
                self.id += 1   
                id_file = open("id.txt","w")
                id_file.write(str(self.id))
                id_file.close()
                
                  
                product["category_of_lot"] = self.get_category_of_lot(grid,response)      
                
                
                product["images"] = self.get_images(grid)
                
                product["lotnumber"] = self.get_lotnumber(grid)
                
                product["description"] = self.get_description(grid)
                
                
                product["condition_of_item"] = self.get_condition_of_item(grid)
                
                product["catalog_number"] = self.get_catalog_number(grid)
                
                product["sold_for"] = grid.css("span[data-nopercent='true']::text").extract_first()
                
                product["estimate"] = grid.css(".meingebot+ td .bidding::text").extract_first()
                
                
                yield product
            time.sleep(1)
                
           # break

            
            if page:
                page[0].click()
            else:
                break
            
        driver.close()
        
            
               


    def get_number_of_auktion(self,response):
        
        product = response.css(".inner-position h1::text").extract()
            
        if "Auction" in product[1]:
            product = product[1].replace("Auction","").strip()
        else:
            product = product[0].split("\n")[0].replace("Auction","").strip()
        
        auktion_flag = 1
        
        for count in range(0,10):
            if str(count) == product[0]:
                auktion_flag = 0
                break
            
        if auktion_flag:
        
            product = 'None'
            
        return product
    
    def get_date_of_auction(self,response):
        
        product = response.css(".inner-position h1::text").extract()[0].split("\xa0-\xa0\n")[1].strip()
        product = product.replace(u'\xa0', u' ')
                
        return product

    def get_images(self,response):
        
        images = response.css(".shadow a::attr(data-imageurl)").extract()
        
        return images

    def get_lotnumber(self,response):
        
        lot = response.css(".lotnumber strong::text").extract_first().strip()
        lot = lot.replace("\n","")
        lot = lot.replace(u"\xa0",u"")
        lot = lot.replace("Lot","")
        lot = lot.replace("los","")
        
        return lot

    def get_description(self,response):
        
        description = response.css(".description::text").extract_first()
        
        return description


    def get_condition_of_item(self,response):
        
        condition = response.css(".erhaltung img::attr(src)").extract()
        
        temp = ""
        
        for img in condition:
            
            if "F" in img:
                temp = str(temp) + "F"
            elif "G" in img:
                temp = str(temp) + "G"
            else:
                for code in ["0","1","2","3","4","5","6","7","8","9"]:
                    
                    if code in img:
                        temp = str(temp) + code
                        
        return temp
            
        
    def get_catalog_number(self,response):
        
        temp = response.css(".kategorie::text").extract_first()
        
        if temp:
            temp = temp.replace("\n","")
            temp = temp.replace("Kat.-Nr.:","")
            temp = temp.strip()
        
        return temp

    def get_category_of_lot(self,grid,response):
        
        category_of_lot = grid.css(".losprint::attr(onclick)").extract_first()        
                
        flag_cat = 0
        
        for cat in response.css(".inner h2"):
        
            temp = cat.css('a::text').extract()
            
                
            for data_temp in temp:
                                        
                if data_temp in category_of_lot:
            
                    temp = "/".join(temp)
                    
                    category_of_lot = temp      
                    flag_cat = 1  
                    break       
                
            if flag_cat:
                break
        
        return category_of_lot