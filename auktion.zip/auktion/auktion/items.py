# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

from scrapy import Field, Item


class AuktionItem(Item):
    
    number_of_auction = Field()
    date_of_auction = Field()
    id = Field()
    
    category_of_lot = Field()
    images = Field()
    
    lotnumber = Field()
    
    description = Field()
    
    condition_of_item = Field()
    
    catalog_number = Field()
    
    estimate = Field()
    sold_for = Field()
    
    pass
