# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html
from scrapy.pipelines.images import ImagesPipeline
import scrapy
import sqlite3

class AuktionImagePipeline(ImagesPipeline):
    def get_media_requests(self, item, info):       
        count = 0
        if not item['images'] == 'None':
            for img_url in item['images']:
                count += 1
                yield scrapy.Request(img_url, meta={'image_name': item["id"],'count': count})

    def file_path(self, request, response=None, info=None):
        return f"{request.meta['image_name']}'_{request.meta['count']}'.jpg" 

class AuktionPipeline(object):

    def __init__(self,new):

        self.create_connection()
        self.create_table(new)
        pass

    @classmethod
    def from_crawler(cls, crawler):
        return cls(new=crawler.spider.new)


    def create_connection(self):

        self.conn = sqlite3.Connection('auktion.db')
        self.curr = self.conn.cursor()
    
    def create_table(self,new):

        if new == "yes":

            self.curr.execute("drop table if exists auktion_table")
            self.curr.execute("CREATE TABLE auktion_table( id text,images text,number_of_auction text,date_of_auction text,category_of_lot text,lotnumber text,description text,condition_of_item text,catalog_number text,estimate text,sold_for text)")

    def process_item(self, item, spider):

        self.store_db(item)

        return item

    def store_db(self,item):

        product_images = ",".join(item["images"])

        self.curr.execute(f"insert into auktion_table values ('{item['id']}','{product_images}','{item['number_of_auction']}','{item['date_of_auction']}','{item['category_of_lot']}','{item['lotnumber']}','{item['description']}','{item['condition_of_item']}','{item['catalog_number']}','{item['estimate']}','{item['sold_for']}')")

        self.conn.commit()